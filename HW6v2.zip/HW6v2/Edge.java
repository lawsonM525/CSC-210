// This class represents an edge between two vertices with specified indices.
import java.awt.Graphics;
import java.util.ArrayList;

public class Edge {
    private Point p1;
    private Point p2;

    public Edge(ArrayList<Point> p, int v1, int v2) {
        this.p1 = p.get(v1);
        this.p2 = p.get(v2);
    }

    public Point getP1() {
        return p1;
    }

    public Point getP2() {
        return p2;
    }

    public String toString() {
        return "(" + p1.getId() + " <-> " + p2.getId() + ")";
    }

    public void drawEdge(Graphics g, Point p1, Point p2 ) {
        //increase size of line
        g.drawLine(p1.x, p1.y, p2.x, p2.y);//draw line
    }


}
