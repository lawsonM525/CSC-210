package Applications.Parantheses;
public class TesterParentheses{

    // test isOpenBracket
    // test isCloseBracket
    //test checkFullArray
}